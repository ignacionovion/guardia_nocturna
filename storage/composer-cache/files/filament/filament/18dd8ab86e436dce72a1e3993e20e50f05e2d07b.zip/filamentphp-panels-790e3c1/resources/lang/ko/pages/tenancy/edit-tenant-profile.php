<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => '변경 사항 저장',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => '저장 완료',
        ],

    ],

];
