<?php

return [

    'body' => 'Jūs turite neišsaugotų pakeitimų. Ar tikrai norite išeiti iš šio puslapio?',

];
