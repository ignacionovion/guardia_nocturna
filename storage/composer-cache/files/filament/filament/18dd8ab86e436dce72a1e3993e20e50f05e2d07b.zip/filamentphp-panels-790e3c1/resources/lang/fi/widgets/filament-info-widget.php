<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Ohjeet',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
