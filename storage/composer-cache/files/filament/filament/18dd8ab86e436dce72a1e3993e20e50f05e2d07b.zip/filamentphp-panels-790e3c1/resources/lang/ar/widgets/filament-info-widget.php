<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'الوثائق',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
