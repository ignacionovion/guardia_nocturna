<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Dokumentace',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
