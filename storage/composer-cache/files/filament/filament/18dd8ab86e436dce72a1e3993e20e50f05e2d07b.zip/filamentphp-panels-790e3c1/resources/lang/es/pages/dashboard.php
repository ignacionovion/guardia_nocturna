<?php

return [

    'title' => 'Escritorio',

    'actions' => [

        'filter' => [

            'label' => 'Filtro',

            'modal' => [

                'heading' => 'Filtro',

                'actions' => [

                    'apply' => [

                        'label' => 'Aplicar',

                    ],

                ],

            ],

        ],

    ],

];
