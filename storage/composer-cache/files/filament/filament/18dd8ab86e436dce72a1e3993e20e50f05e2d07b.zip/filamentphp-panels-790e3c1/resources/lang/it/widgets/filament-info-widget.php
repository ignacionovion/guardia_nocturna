<?php

return [

    'actions' => [

        'open_documentation' => [
            'label' => 'Documentazione',
        ],

        'open_github' => [
            'label' => 'GitHub',
        ],

    ],

];
