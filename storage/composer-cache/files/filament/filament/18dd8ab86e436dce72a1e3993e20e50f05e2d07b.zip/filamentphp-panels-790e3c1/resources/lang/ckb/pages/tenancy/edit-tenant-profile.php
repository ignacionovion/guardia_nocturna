<?php

return [

    'form' => [

        'actions' => [

            'save' => [
                'label' => 'نوێکردنەوە',
            ],

        ],

    ],

    'notifications' => [

        'saved' => [
            'title' => 'نوێکرایەوە',
        ],

    ],

];
