<?php

return [

    'actions' => [

        'logout' => [
            'label' => 'تسجيل الخروج',
        ],

    ],

    'welcome' => 'مرحباً',

];
