<?php

return [

    'breadcrumb' => 'Popis',

];
