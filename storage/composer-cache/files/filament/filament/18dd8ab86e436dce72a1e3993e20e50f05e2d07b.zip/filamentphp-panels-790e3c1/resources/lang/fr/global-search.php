<?php

return [

    'field' => [
        'label' => 'Recherche globale',
        'placeholder' => 'Rechercher',
    ],

    'no_results_message' => "Désolé, aucun résultat n'a été trouvé.",

];
