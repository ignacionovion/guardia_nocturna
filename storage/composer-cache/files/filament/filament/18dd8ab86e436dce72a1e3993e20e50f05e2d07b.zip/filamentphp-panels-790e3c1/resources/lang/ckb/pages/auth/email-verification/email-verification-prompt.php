<?php

return [

    'title' => 'چالاککردنی ئیمەیڵ',

    'heading' => 'چالاککردنی ئیمەیڵ',

    'actions' => [

        'resend_notification' => [
            'label' => 'دووبارە چالاککردن بنێرە',
        ],

    ],

    'messages' => [
        'notification_not_received' => 'ئیمەیڵەکەت پێ نەگەیشت بۆ چالاککردن؟',
        'notification_sent' => 'ئیمەیڵێکمان نارد بۆ :email کە ڕێنماییەکەنی تێدایە بۆ چالاککردنی هەژمارەکەت..',
    ],

    'notifications' => [

        'notification_resent' => [
            'title' => 'چالاککردنی ئیمەیڵ دووبارە نێردرا.',
        ],

        'notification_resend_throttled' => [
            'title' => 'هەوڵی دووبارە ناردنی چالاککردن زۆر نێردرا',
            'body' => 'تکایە هەوڵ بدەرەوە دوای :seconds چرکە.',
        ],

    ],

];
