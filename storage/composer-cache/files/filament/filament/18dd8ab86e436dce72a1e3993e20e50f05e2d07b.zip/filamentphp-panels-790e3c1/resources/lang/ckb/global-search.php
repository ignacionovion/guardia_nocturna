<?php

return [

    'field' => [
        'label' => 'گەڕانی گشتی',
        'placeholder' => 'گەڕان',
    ],

    'no_results_message' => 'هیچ ئەنجامێک بۆ گەڕانەکەت نەدۆزرایەوە.',

];
