<?php

return [

    'distinct' => [
        'must_be_selected' => 'En az 1 adet :attribute alanı seçmelisiniz.',
        'only_one_must_be_selected' => 'Sadece 1 adet :attribute alanı seçilmelidir.',
    ],

];
