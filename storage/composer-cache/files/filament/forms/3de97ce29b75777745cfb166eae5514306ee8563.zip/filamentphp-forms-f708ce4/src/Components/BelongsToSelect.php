<?php

namespace Filament\Forms\Components;

/**
 * @deprecated Use `Select` with the `relationship()` method instead.
 */
class BelongsToSelect extends Select {}
