<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'Mostrar menos :count',
                'expand_list' => 'Mostrar mais :count',
            ],

            'more_list_items' => 'e mais :count',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'Chave',
                ],

                'value' => [
                    'label' => 'Valor',
                ],

            ],

            'placeholder' => 'Sem dados',

        ],

    ],

];
