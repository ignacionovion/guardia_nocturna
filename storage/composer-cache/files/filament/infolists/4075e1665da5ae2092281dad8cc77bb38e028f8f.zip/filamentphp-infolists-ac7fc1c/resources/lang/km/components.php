<?php

return [

    'entries' => [

        'text' => [

            'actions' => [
                'collapse_list' => 'បង្ហាញ :count តិច',
                'expand_list' => 'បង្ហាញ :count ច្រើនទៀត',
            ],

            'more_list_items' => 'និង :count ច្រើនទៀត',

        ],

        'key_value' => [

            'columns' => [

                'key' => [
                    'label' => 'សោ',
                ],

                'value' => [
                    'label' => 'តម្លៃ',
                ],

            ],

            'placeholder' => 'គ្មានទិន្ន័យទេ',

        ],

    ],

];
