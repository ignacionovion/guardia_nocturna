<?php

return [

    'messages' => [
        'copied' => 'Copiat',
    ],

];
