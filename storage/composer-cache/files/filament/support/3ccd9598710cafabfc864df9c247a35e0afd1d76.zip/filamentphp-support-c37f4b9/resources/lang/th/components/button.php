<?php

return [

    'messages' => [
        'uploading_file' => 'กำลังอัปโหลดไฟล์...',
    ],

];
