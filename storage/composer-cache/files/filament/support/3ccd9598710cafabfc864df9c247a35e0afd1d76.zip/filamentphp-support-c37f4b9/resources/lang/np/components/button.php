<?php

return [

    'messages' => [
        'uploading_file' => 'फाइल अपलोड गर्दै...',
    ],

];
