<?php

return [

    'actions' => [

        'close' => [
            'label' => 'داخستن',
        ],

    ],

];
