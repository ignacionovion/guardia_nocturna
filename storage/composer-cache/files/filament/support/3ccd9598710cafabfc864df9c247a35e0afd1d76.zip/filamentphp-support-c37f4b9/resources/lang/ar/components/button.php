<?php

return [

    'messages' => [
        'uploading_file' => 'جاري رفع الملف...',
    ],

];
