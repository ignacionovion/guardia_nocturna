<?php

return [

    'messages' => [
        'copied' => 'Αντιγράφηκε',
    ],

];
