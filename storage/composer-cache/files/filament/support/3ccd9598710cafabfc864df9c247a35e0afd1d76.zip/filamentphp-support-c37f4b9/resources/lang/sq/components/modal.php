<?php

return [

    'actions' => [

        'close' => [
            'label' => 'Mbyll',
        ],

    ],

];
