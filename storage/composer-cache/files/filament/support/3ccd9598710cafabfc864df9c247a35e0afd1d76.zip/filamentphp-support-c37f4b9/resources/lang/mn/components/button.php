<?php

return [

    'messages' => [
        'uploading_file' => 'Хуулж байна...',
    ],

];
