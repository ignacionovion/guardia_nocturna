<?php

return [

    'messages' => [
        'copied' => '복사 완료',
    ],

];
