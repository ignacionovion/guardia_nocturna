<?php

return [

    'messages' => [
        'copied' => 'Պատճենված է',
    ],

];
