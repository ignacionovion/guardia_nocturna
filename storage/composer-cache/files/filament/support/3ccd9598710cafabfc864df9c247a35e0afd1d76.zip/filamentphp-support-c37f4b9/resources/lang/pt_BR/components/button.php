<?php

return [

    'messages' => [
        'uploading_file' => 'Enviando arquivo...',
    ],

];
