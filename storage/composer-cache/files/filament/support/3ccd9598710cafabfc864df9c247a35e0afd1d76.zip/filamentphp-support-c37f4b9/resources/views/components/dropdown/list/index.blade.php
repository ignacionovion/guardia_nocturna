<div {{ $attributes->class(['fi-dropdown-list p-1']) }}>
    {{ $slot }}
</div>
