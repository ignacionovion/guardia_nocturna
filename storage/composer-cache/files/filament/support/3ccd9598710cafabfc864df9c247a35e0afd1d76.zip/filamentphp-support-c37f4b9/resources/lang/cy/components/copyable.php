<?php

return [

    'messages' => [
        'copied' => 'Wedi Copïo',
    ],

];
