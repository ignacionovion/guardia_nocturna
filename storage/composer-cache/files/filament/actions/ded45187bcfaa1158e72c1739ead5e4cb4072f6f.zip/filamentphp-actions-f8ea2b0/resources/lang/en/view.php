<?php

return [

    'single' => [

        'label' => 'View',

        'modal' => [

            'heading' => 'View :label',

            'actions' => [

                'close' => [
                    'label' => 'Close',
                ],

            ],

        ],

    ],

];
