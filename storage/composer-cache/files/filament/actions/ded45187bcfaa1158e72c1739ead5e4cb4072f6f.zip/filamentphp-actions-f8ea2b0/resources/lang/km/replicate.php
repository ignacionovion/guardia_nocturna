<?php

return [

    'single' => [

        'label' => 'ចម្លង',

        'modal' => [

            'heading' => 'ចម្លង :label',

            'actions' => [

                'replicate' => [
                    'label' => 'ចម្លង',
                ],

            ],

        ],

        'notifications' => [

            'replicated' => [
                'title' => 'ចម្លង',
            ],

        ],

    ],

];
