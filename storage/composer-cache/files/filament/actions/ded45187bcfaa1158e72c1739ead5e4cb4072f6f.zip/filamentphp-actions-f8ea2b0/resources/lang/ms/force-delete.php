<?php

return [

    'single' => [

        'label' => 'Padam paksa',

        'modal' => [

            'heading' => 'Padam paksa :label',

            'actions' => [

                'delete' => [
                    'label' => 'Padam',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Terpadam',
            ],

        ],

    ],

    'multiple' => [

        'label' => 'Padam paksa pilihan',

        'modal' => [

            'heading' => 'Padam paksa pilihan :label',

            'actions' => [

                'delete' => [
                    'label' => 'Padam',
                ],

            ],

        ],

        'notifications' => [

            'deleted' => [
                'title' => 'Terpadam',
            ],

        ],

    ],

];
