<?php

return [

    'single' => [

        'label' => ':label חדש',

        'modal' => [

            'heading' => 'יצירת :label',

            'actions' => [

                'create' => [
                    'label' => 'צור',
                ],

                'create_another' => [
                    'label' => 'צור וצור עוד אחד',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'נוצר',
            ],

        ],

    ],

];
