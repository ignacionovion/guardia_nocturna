<?php

return [

    'single' => [

        'label' => 'Opret :label',

        'modal' => [

            'heading' => 'Opret :label',

            'actions' => [

                'create' => [
                    'label' => 'Opret',
                ],

                'create_another' => [
                    'label' => 'Opret & opret en mere',
                ],

            ],

        ],

        'notifications' => [

            'created' => [
                'title' => 'Oprettet',
            ],

        ],

    ],

];
