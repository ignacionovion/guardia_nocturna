<?php

return [

    'single' => [

        'label' => 'Näytä',

        'modal' => [

            'heading' => 'Näytä :label',

            'actions' => [

                'close' => [
                    'label' => 'Sulje',
                ],

            ],

        ],

    ],

];
