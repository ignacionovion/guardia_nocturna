<?php

return [

    'single' => [

        'label' => 'Закачи',

        'modal' => [

            'heading' => 'Закачи :label',

            'fields' => [

                'record_id' => [
                    'label' => 'Запис',
                ],

            ],

            'actions' => [

                'attach' => [
                    'label' => 'Закачи',
                ],

                'attach_another' => [
                    'label' => 'Закачи и закачи друг',
                ],

            ],

        ],

        'notifications' => [

            'attached' => [
                'title' => 'Закачен',
            ],

        ],

    ],

];
